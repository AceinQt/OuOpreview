   // 长按功能
function createContextMenu(items, x, y) {
    removeContextMenu(); // 移除旧菜单
    
    const menu = document.createElement('div');
    menu.className = 'context-menu';
    
    // 生成菜单项
    items.forEach(item => {
        const menuItem = document.createElement('div');
        menuItem.className = 'context-menu-item';
        if (item.danger) menuItem.classList.add('danger');
        menuItem.textContent = item.label;
        menuItem.onclick = (e) => {
            e.stopPropagation(); // 阻止冒泡
            item.action();
            removeContextMenu();
        };
        menu.appendChild(menuItem);
    });

    // 核心修复：直接添加到 DOM 中（不需要 visibility: hidden）
    // 浏览器在当前 JS 代码块执行完之前，不会把半成品画到屏幕上
    document.body.appendChild(menu);

    // 获取尺寸
    const menuRect = menu.getBoundingClientRect();
    const windowHeight = window.innerHeight;
    const windowWidth = window.innerWidth;

    // --- 智能定位逻辑 ---
    if (y + menuRect.height > windowHeight - 10) { 
        menu.style.top = `${y - menuRect.height}px`;
        menu.style.transformOrigin = 'bottom left';
    } else {
        menu.style.top = `${y}px`;
        menu.style.transformOrigin = 'top left';
    }

    if (x + menuRect.width > windowWidth) {
        menu.style.left = `${windowWidth - menuRect.width - 10}px`;
    } else {
        menu.style.left = `${x}px`;
    }

    // 核心修复：稍微延迟一点再绑定全局点击关闭事件
    // 移动端长按抬手时会触发 touchend -> click，延迟 100ms 可完美避开这个抬手误触
    setTimeout(() => {
        document.addEventListener('click', removeContextMenu, { once: true });
    }, 0);
}

            function removeContextMenu() {
                const menu = document.querySelector('.context-menu');
                if (menu) menu.remove();
            }                                          
            function handleMessageLongPress(messageWrapper, x, y) {
            if (isInMultiSelectMode) return;
            clearTimeout(longPressTimer);
            const messageId = messageWrapper.dataset.id;
            const chat = (currentChatType === 'private') ? db.characters.find(c => c.id === currentChatId) : db.groups.find(g => g.id === currentChatId);
            const message = chat.history.find(m => m.id === messageId);
            if (!message) return;

            // --- 核心判断逻辑 ---
            const isNarration = /\[system-narration:[\s\S]+?\]/.test(message.content);
            const isTimeSkip = /\[system-display:[\s\S]+?\]/.test(message.content);
            const isWithdrawn = message.isWithdrawn;
            const isOfflineMode = (currentChatType === 'private' && chat.offlineModeEnabled);
            
            let menuItems = [];

            if (isNarration) {
                // --- 旁白菜单 ---
                
                // 1. 复制功能 (使用增强版函数)
                menuItems.push({
                    label: '复制', 
                    action: () => {
                        // A. 尝试提取 [system-narration:...] 里面的内容
                        const match = message.content.match(/\[system-narration:([\s\S]+?)\]/);
                        let textToCopy = match ? match[1] : message.content;
                        
                        // B. 如果提取失败（可能是旧数据或格式不匹配），尝试去掉可能的首尾括号
                        if (!match && textToCopy.startsWith('[') && textToCopy.endsWith(']')) {
                            textToCopy = textToCopy.substring(1, textToCopy.length - 1);
                        }

                        // C. 清洗 Markdown 符号 (把 *斜体* 还原为普通文字)
                        // 将 *文字* 替换为 文字
                        textToCopy = textToCopy.replace(/\*([^*]+)\*/g, '$1').trim();
                        
                        // D. 执行复制
                        copyTextToClipboard(textToCopy)
                            .then(() => showToast('已复制'))
                            .catch((err) => {
                                console.error(err);
                                showToast('复制失败，请重试');
                            });
                    }
                });

                // 2. 编辑功能
                menuItems.push({label: '编辑', action: () => startMessageEdit(messageId)});

                // 3. 删除功能
                menuItems.push({label: '删除', action: () => enterMultiSelectMode(messageId)});

            } else if (isTimeSkip) {
        // --- 新增：时间跳过/剧情显示消息 ---
        menuItems.push({
            label: '复制',
            action: () => {
                const match = message.content.match(/\[system-display:([\s\S]+?)\]/);
                copyTextToClipboard(match ? match[1] : message.content).then(() => showToast('已复制'));
            }
        });
            // 允许编辑
        menuItems.push({label: '编辑', action: () => startMessageEdit(messageId)});
        menuItems.push({label: '删除', action: () => enterMultiSelectMode(messageId)});
            
          } else {
                // --- 普通消息菜单 (保持原有) ---
                const isImageRecognitionMsg = message.parts && message.parts.some(p => p.type === 'image');
                const isStickerMessage = /\[.*?的表情包[:：].*?\]|\[.*?发送的表情包[:：].*?\]/.test(message.content);
                const isTransferMessage = /\[.*?给你转账[:：].*?\]|\[.*?的转账[:：].*?\]|\[.*?向.*?转账[:：].*?\]/.test(message.content);
                const isGiftMessage = /\[.*?送来的礼物[:：].*?\]|\[.*?向.*?送来了礼物[:：].*?\]/.test(message.content);
                const isLocationMessage = /\[.*?发送了位置[:：].*?\]/.test(message.content);
                const isInvisibleMessage = /\[.*?(?:接收|退回).*?的转账\]|\[.*?更新状态为[:：].*?\]|\[.*?已接收礼物\]|\[system:.*?\]|\[.*?邀请.*?加入了群聊\]|\[.*?将.*?移出了群聊\]|\[.*?修改群名为[:：].*?\]|\[.*?修改.*?的群昵称为[:：].*?\]/.test(message.content);

                if (!isWithdrawn) {
                    // 普通对话、语音、照片/视频（图文）共用同一套编辑弹窗，且可互相转换。
                    if (!isImageRecognitionMsg && !isStickerMessage && !isTransferMessage && !isGiftMessage && !isLocationMessage && !isInvisibleMessage) {
                         menuItems.push({
                            label: '复制',
                            action: () => {
                                const editableMatch = message.content.match(/^\[(?:.+?)(?:的消息|的语音|发来的照片\/视频)[:：]\s*([\s\S]*?)\]$/);
                                const text = editableMatch ? editableMatch[1].trim() : message.content;
                                copyTextToClipboard(text)
                                    .then(() => showToast('已复制'))
                                    .catch(() => showToast('复制失败'));
                            }
                        });
                        menuItems.push({label: '编辑', action: () => startMessageEdit(messageId)});
                    }
                    
                    
                    if (!isInvisibleMessage) {
                        if (!isOfflineMode) {
                    menuItems.push({label: '引用', action: () => startQuoteReply(messageId)});
                }
                    }

                    if (message.role === 'user') {
                        if (!isOfflineMode) {
                    menuItems.push({label: '撤回', action: () => withdrawMessage(messageId)});
                }
                    }

                    // 语音消息：重新生成音频
                    // ★ 缓存键只认预设 id 不认预设内容，所以调语速/改描述/换音色都不会
                    //   让已有音频自动作废（免得每次微调都白花一次合成的钱）。
                    //   这里是那个策略必需的手动出口。
                    const isVoiceMessage = typeof parseVoiceMessage === 'function'
                        && !!parseVoiceMessage(message.content)
                        && message.role !== 'user';
                    if (isVoiceMessage && typeof regenerateVoiceClip === 'function') {
                        menuItems.push({
                            label: '重新生成语音',
                            action: () => regenerateVoiceClip(messageId, chat, currentChatType)
                        });
                    }

                    // 语音消息：把音频存成 mp3 文件
                    // ★ 不检查"有没有生成过"就放这一项 —— 那要查一次 IndexedDB，
                    //   而长按菜单是同步构建的。没生成过的情况由 downloadVoiceClip
                    //   自己提示"先点播放键生成"。
                    if (isVoiceMessage && typeof downloadVoiceClip === 'function') {
                        menuItems.push({
                            label: '下载语音',
                            action: () => downloadVoiceClip(messageId, chat, currentChatType)
                        });
                    }

                    // 图片消息：转文字描述（省 token）
                    if (isImageRecognitionMsg) {
                        const isConverting = (typeof isImageConverting === 'function') && isImageConverting(messageId);
                        menuItems.push({
                            label: isConverting ? '转化中…' : '转文字',
                            action: () => {
                                if (isConverting) { showToast('该图片正在转化中'); return; }
                                convertImageMessageToText(messageId);
                            }
                        });
                    }
                }
                menuItems.push({label: '删除', action: () => enterMultiSelectMode(messageId)});
            }

            if (menuItems.length > 0) {
                createContextMenu(menuItems, x, y);
            }
        }
        
            // --- 新增：引用功能相关函数 ---
            function startQuoteReply(messageId) {
                const chat = (currentChatType === 'private') ? db.characters.find(c => c.id === currentChatId) : db.groups.find(g => g.id === currentChatId);
                const message = chat.history.find(m => m.id === messageId);
                if (!message) return;

                let senderName = '';
                let senderId = '';
                if (message.role === 'user') {
                    senderName = (currentChatType === 'private') ? chat.myName : chat.me.realName;
                    senderId = 'user_me';
                } else { // assistant
                    if (currentChatType === 'private') {
                        senderName = chat.remarkName;
                        senderId = chat.id;
                    } else {
                        const sender = findGroupMemberById(chat, message.senderId);
                        senderName = sender ? sender.groupNickname : '未知成员';
                        senderId = sender ? sender.id : 'unknown';
                    }
                }

                // 提取纯文本内容用于预览
                let previewContent = message.content;
                const textMatch = message.content.match(/\[.*?的消息：([\s\S]+?)\]/);
                if (textMatch) {
                    previewContent = textMatch[1];
                } else if (/\[.*?的表情包：.*?\]/.test(message.content)) {
                    previewContent = '[表情包]';
                } else if (/\[.*?的语音：.*?\]/.test(message.content)) {
                    previewContent = '[语音]';
                } else if (/\[.*?发来的照片\/视频：.*?\]/.test(message.content)) {
                    previewContent = '[照片/视频]';
                } else if (/\[.*?发送了位置：.*?\]/.test(message.content)) {
                    previewContent = '[位置]';
                } else if (message.parts && message.parts.some(p => p.type === 'image')) {
                    previewContent = '[图片]';
                }

                currentQuoteInfo = {
                    id: message.id,
                    senderId: senderId,
                    senderName: senderName,
                    content: previewContent.substring(0, 100) // 截断以防过长
                };

                const previewBar = document.getElementById('reply-preview-bar');
                previewBar.querySelector('.reply-preview-name').textContent = `回复 ${senderName}`;
                previewBar.querySelector('.reply-preview-text').textContent = currentQuoteInfo.content;
                previewBar.classList.add('visible');

                messageInput.focus();
            }

            function cancelQuoteReply() {
                currentQuoteInfo = null;
                const previewBar = document.getElementById('reply-preview-bar');
                previewBar.classList.remove('visible');
            }
           
            
              // --- 编辑功能 ---
            
// --- 替换 startMessageEdit 函数 ---
function startMessageEdit(messageId) {
    exitMultiSelectMode();
    editingMessageId = messageId;
    const chat = (currentChatType === 'private') ? db.characters.find(c => c.id === currentChatId) : db.groups.find(g => g.id === currentChatId);
    const message = chat.history.find(m => m.id === messageId);
    if (!message) return;

    const modal = document.getElementById('message-edit-modal');
    const textarea = document.getElementById('message-edit-textarea');
    const typeSelect = document.getElementById('message-edit-type'); // 获取下拉框

    let contentToEdit = message.content;
    let currentType = 'text'; // 默认为普通文本

    // --- 1. 智能识别当前类型并提取纯文本 ---
    
    // A. 剧情旁白 [system-narration:...]
    const narrationMatch = contentToEdit.match(/^\[system-narration:([\s\S]+?)\]$/);
    // B. 屏幕通知/时间跳过 [system-display:...]
    const displayMatch = contentToEdit.match(/^\[system-display:([\s\S]+?)\]$/);
    // C. 纯系统指令 [system:...]
    const systemMatch = contentToEdit.match(/^\[system:([\s\S]+?)\]$/);
    // D. 普通对话、语音和照片/视频（同时兼容中英文冒号）
    const plainTextMatch = contentToEdit.match(/^\[.*?的消息[:：]\s*([\s\S]*)\]$/);
    const voiceMatch = contentToEdit.match(/^\[.*?的语音[:：]\s*([\s\S]*)\]$/);
    const photoVideoMatch = contentToEdit.match(/^\[.*?发来的照片\/视频[:：]\s*([\s\S]*)\]$/);

    if (narrationMatch) {
        contentToEdit = narrationMatch[1].trim();
        currentType = 'narration';
    } else if (displayMatch) {
        contentToEdit = displayMatch[1].trim();
        currentType = 'display';
    } else if (systemMatch) {
        contentToEdit = systemMatch[1].trim();
        currentType = 'system';
    } else if (voiceMatch) {
        contentToEdit = voiceMatch[1].trim();
        currentType = 'voice';
    } else if (photoVideoMatch) {
        contentToEdit = photoVideoMatch[1].trim();
        currentType = 'photo-video';
    } else if (plainTextMatch && plainTextMatch[1]) {
        contentToEdit = plainTextMatch[1].trim();
        currentType = 'text';
    } else {
        // 兜底：如果都没有匹配上，可能是纯文本或特殊格式，视为普通文本，但清理一下可能的发送时间戳
        contentToEdit = contentToEdit.replace(/\[发送时间:.*?\]/g, '').trim();
        currentType = 'text';
    }

    // --- 2. 赋值给 UI ---
    textarea.value = contentToEdit;
    if (typeSelect) {
        typeSelect.value = currentType; // 设置下拉框选中状态
    }
    
    modal.classList.add('visible');
    // 稍微延迟聚焦，体验更好
    setTimeout(() => textarea.focus(), 50);
}

// --- saveMessageEdit 函数 ---
async function saveMessageEdit() {
    const textarea = document.getElementById('message-edit-textarea');
    const typeSelect = document.getElementById('message-edit-type');
    const newText = textarea.value.trim();
    
    if (!newText || !editingMessageId) {
        cancelMessageEdit();
        return;
    }

    const chat = (currentChatType === 'private') ? db.characters.find(c => c.id === currentChatId) : db.groups.find(g => g.id === currentChatId);
    const messageIndex = chat.history.findIndex(m => m.id === editingMessageId);
    if (messageIndex === -1) {
        cancelMessageEdit();
        return;
    }

    const message = chat.history[messageIndex];
    const selectedType = typeSelect ? typeSelect.value : 'text'; 

    let newContent = '';

    // --- 核心：根据下拉框类型构建新消息格式 ---
    let senderName = '';
    if (message.role === 'user') {
        senderName = (currentChatType === 'private') ? chat.myName : chat.me.realName;
    } else if (currentChatType === 'private') {
        senderName = chat.realName || chat.name;
    } else {
        const sender = findGroupMemberById(chat, message.senderId);
        senderName = sender ? sender.groupNickname : (chat.name || '未知成员');
    }

    if (selectedType === 'narration') {
        newContent = `[system-narration:${newText}]`;
    } else if (selectedType === 'display') {
        newContent = `[system-display:${newText}]`;
        if (message.id.startsWith('msg_visual_')) {
            const timestampSuffix = message.id.replace('msg_visual_', '');
            const contextMsgId = `msg_context_${timestampSuffix}`;
            const contextMsg = chat.history.find(m => m.id === contextMsgId);
            if (contextMsg) {
                const newContextContent = `[剧情旁白：${newText}]`;
                contextMsg.content = newContextContent;
                contextMsg.parts = [{ type: 'text', text: newContextContent }];
            }
        }
    } else if (selectedType === 'voice') {
        newContent = `[${senderName}的语音：${newText}]`;
    } else if (selectedType === 'photo-video') {
        newContent = `[${senderName}发来的照片/视频：${newText}]`;
    } else {
        newContent = `[${senderName}的消息：${newText}]`;
    }

    // 转换后统一落为纯文字 parts，避免旧格式残留导致渲染器继续误判气泡类型。
    chat.history[messageIndex].content = newContent;
    chat.history[messageIndex].parts = [{ type: 'text', text: newContent }];

    await saveMessageToDB(chat.history[messageIndex], currentChatId, currentChatType);
    await saveSingleChat(currentChatId, currentChatType);
    
    // ==========================================
    // 【核心修复】原地 DOM 替换，解决跳转和消息丢失问题
    // ==========================================
    
    // 1. 在页面上找到旧的消息气泡 DOM 元素
    const existingBubble = messageArea.querySelector(`.message-wrapper[data-id="${editingMessageId}"]`);

    // 2. 使用现有的函数生成一个新的气泡 DOM 元素
    // 注意：createMessageBubbleElement 依赖已更新的 chat.history 数据
    const newBubble = createMessageBubbleElement(chat.history[messageIndex]);

    if (existingBubble) {
        if (typeof releaseImageObjectUrlsWithin === 'function') {
            releaseImageObjectUrlsWithin(existingBubble);
        }
        if (newBubble) {
            // 3a. 如果新气泡生成成功，直接替换旧气泡
            // 这会保留浏览器当前的滚动位置，因为元素高度变化通常不会剧烈影响视口定位
            existingBubble.replaceWith(newBubble);
            
 
        } else {
            // 3b. 如果新内容导致气泡不可见（例如改成了隐藏指令），则移除元素
            existingBubble.remove();
        }
    } else {
        // 4. 兜底：如果找不到旧元素（极少情况），才调用原来的重绘逻辑
        // 但为了防止丢失最新消息，这里建议什么都不做，或者只重绘
        // 只有当真的找不到元素时，我们才被迫重绘
        renderMessages(false, false); 
    }
    
    cancelMessageEdit();
}

            function cancelMessageEdit() {
                editingMessageId = null;
                const modal = document.getElementById('message-edit-modal');
                if (modal) {
                    modal.classList.remove('visible');
                }
            }
            
function enterMultiSelectMode(initialMessageId) {
                isInMultiSelectMode = true;
                chatRoomHeaderDefault.style.display = 'none';
                chatRoomHeaderSelect.style.display = 'flex';
                document.querySelector('.chat-input-wrapper').style.display = 'none';
                multiSelectBar.classList.add('visible');
                chatRoomScreen.classList.add('multi-select-active');
                selectedMessageIds.clear();
                if (initialMessageId) {
                    toggleMessageSelection(initialMessageId);
                }
            }

            function exitMultiSelectMode() {
                isInMultiSelectMode = false;
                chatRoomHeaderDefault.style.display = 'flex';
                chatRoomHeaderSelect.style.display = 'none';
                document.querySelector('.chat-input-wrapper').style.display = 'block';
                multiSelectBar.classList.remove('visible');
                chatRoomScreen.classList.remove('multi-select-active');
                selectedMessageIds.forEach(id => {
                    const el = messageArea.querySelector(`.message-wrapper[data-id="${id}"]`);
                    if (el) el.classList.remove('multi-select-selected');
                });
                selectedMessageIds.clear();
            }

            function toggleMessageSelection(messageId) {
                const el = messageArea.querySelector(`.message-wrapper[data-id="${messageId}"]`);
                if (!el) return;
                if (selectedMessageIds.has(messageId)) {
                    selectedMessageIds.delete(messageId);
                    el.classList.remove('multi-select-selected');
                } else {
                    selectedMessageIds.add(messageId);
                    el.classList.add('multi-select-selected');
                }
                selectCount.textContent = `已选择 ${selectedMessageIds.size} 项`;
                deleteSelectedBtn.disabled = selectedMessageIds.size === 0;
            }

            async function deleteSelectedMessages() {
                if (selectedMessageIds.size === 0) return;
                const deletedCount = selectedMessageIds.size;
                const chat = (currentChatType === 'private') ? db.characters.find(c => c.id === currentChatId) : db.groups.find(g => g.id === currentChatId);
                chat.history = chat.history.filter(m => !selectedMessageIds.has(m.id));
                await deleteMessagesFromDB(Array.from(selectedMessageIds));
    await saveSingleChat(currentChatId, currentChatType);
                currentPage = 1;
                renderMessages(false, true);
                renderChatList();
                exitMultiSelectMode();
                showToast(`已删除 ${deletedCount} 条消息`);
            }
            
            // --- 新增：撤回消息函数 ---
 // --- 找到这个函数 ---
async function withdrawMessage(messageId) {
    const chat = (currentChatType === 'private') ? db.characters.find(c => c.id === currentChatId) : db.groups.find(g => g.id === currentChatId);
    if (!chat) return;

    const messageIndex = chat.history.findIndex(m => m.id === messageId);
    if (messageIndex === -1) return;

    const message = chat.history[messageIndex];
    const messageTime = message.timestamp;
    const now = Date.now();

    if (now - messageTime > 2 * 60 * 1000) {
        showToast('超过2分钟的消息无法撤回');
        return;
    }

    // 更新数据模型
    message.isWithdrawn = true;

    // 提取干净的原始内容用于AI上下文和UI的“重新编辑”
    const cleanContentMatch = message.content.match(/\[.*?的消息：([\s\S]+?)\]/);
    const cleanOriginalContent = cleanContentMatch ? cleanContentMatch[1] : message.content;
    message.originalContent = cleanOriginalContent; // 保存干净的原始内容

    // 获取当前用户的昵称
    const myName = (currentChatType === 'private') ? chat.myName : chat.me.realName;

    // 为AI生成新的、可理解的上下文消息
    const newContent = `[${myName} 撤回了一条消息：${cleanOriginalContent}]`; // 定义新内容变量
    
    message.content = newContent; // 1. 更新 content

    // ==========================================
    // 【核心修复】同步更新 parts
    // 这样 getAiReply 读取 parts 时才能看到撤回提示
    // ==========================================
    if (message.parts) {
        message.parts = [{ type: 'text', text: newContent }];
    }

    // 保存数据
    await saveMessageToDB(message, currentChatId, currentChatType);
    await saveSingleChat(currentChatId, currentChatType);

    // 重新渲染
    currentPage = 1;
    renderMessages(false, true);
    renderChatList();
    showToast('消息已撤回');
}
