            // --- 线下模式 ---
            async function openOfflineModeSettings() {
                if (currentChatType !== 'private') {
                    showToast('线下模式仅支持单人聊天');
                    return;
                }
                const chat = db.characters.find(c => c.id === currentChatId);
                if (!chat) return;

                const wasEnabled = chat.offlineModeEnabled;
                const isNowEnabled = !wasEnabled; // 直接取反

                // 使用专用的 AppUI.confirm 替代原生 confirm
                const confirmMsg = isNowEnabled 
                    ? '确定要开启线下模式吗？\n开启后将进入面对面互动模式。' 
                    : '确定要关闭线下模式吗？\n关闭后将恢复正常的手机聊天。';

                const isConfirmed = await AppUI.confirm(confirmMsg, "模式切换");
                
                if (!isConfirmed) {
                    return; // 用户点击取消则中断
                }

                // 确认后更新数据
                chat.offlineModeEnabled = isNowEnabled;
                const now = Date.now();

                // 切换线下模式影响 peek 是否可推，撤销该会话待发的 CF 任务，下次进后台按新状态重排
                if (window.PushNode && typeof window.PushNode.cancelChat === 'function') {
                    window.PushNode.cancelChat(chat).catch(() => {});
                }

                // =======================================================
                // 情况 1: 退出线下模式
                // =======================================================
                if (wasEnabled && !isNowEnabled) {
                    const endInstruction = `[system: 面对面情节结束。切换回手机聊天模式。恢复使用“${chat.realName}的消息…”格式。]`;
                    const instructionMsg = {
                        id: `msg_ins_off_${now}_${Math.random().toString(36).substr(2, 6)}`,
                        role: 'user', 
                        content: endInstruction,
                        parts:[{ type: 'text', text: endInstruction }],
                        timestamp: now,
                        isHidden: true
                    };
                    chat.history.push(instructionMsg);

                    const displayMsg = {
                        id: `msg_vis_off_${now}_${Math.random().toString(36).substr(2, 6)}`,
                        role: 'system',
                        content: `[system-display: 已退出线下模式]`,
                        parts:[],
                        timestamp: now + 1,
                        isAiIgnore: true 
                    };
                    chat.history.push(displayMsg);
                    addMessageBubble(displayMsg, currentChatId, currentChatType);
                    await saveMessagesToDB([instructionMsg, displayMsg], currentChatId, currentChatType); 
                }
                // =======================================================
                // 情况 2: 进入线下模式
                // =======================================================
                else if (!wasEnabled && isNowEnabled) {
                    const startInstruction = `[system: 场景切换：从现在开始，${chat.realName}与用户进行【面对面】互动。请根据人设直接描写动作和语言。]`;
                    const instructionMsg = {
                        id: `msg_ins_on_${now}_${Math.random().toString(36).substr(2, 6)}`,
                        role: 'user', 
                        content: startInstruction,
                        parts:[{ type: 'text', text: startInstruction }],
                        timestamp: now,
                        isHidden: true 
                    };
                    chat.history.push(instructionMsg);

                    const displayMsg = {
                        id: `msg_vis_on_${now}_${Math.random().toString(36).substr(2, 6)}`,
                        role: 'system',
                        content: `[system-display: 已开启线下模式]`,
                        parts:[],
                        timestamp: now + 1,
                        isAiIgnore: true 
                    };
                    chat.history.push(displayMsg);
                    addMessageBubble(displayMsg, currentChatId, currentChatType);
                    await saveMessagesToDB([instructionMsg, displayMsg], currentChatId, currentChatType);
                }

                await saveSingleChat(currentChatId, currentChatType);

                // 更新界面按钮状态和顶部呼吸灯
                updateOfflineModeUI(chat.offlineModeEnabled);

                // "+"面板的高亮和线上功能置灰统一走 syncChatExpansionActiveState，
                // 别在这里手动 toggle class，否则两处状态容易走偏
                if (typeof syncChatExpansionActiveState === 'function') {
                    syncChatExpansionActiveState();
                }

                showToast(chat.offlineModeEnabled ? '线下模式已开启' : '线下模式已关闭');
            }

            function applyOfflineNarrationCss(chatId, css) {
                const styleId = `offline-narration-style-${chatId}`;
                let styleElement = document.getElementById(styleId);

                if (css && css.trim()) {
                    if (!styleElement) {
                        styleElement = document.createElement('style');
                        styleElement.id = styleId;
                        document.head.appendChild(styleElement);
                    }
                    // 限制作用域在当前聊天室
                    const scopedCss = `#chat-room-screen.chat-active-${chatId} ${css}`;
                    styleElement.textContent = scopedCss;
                } else {
                    if (styleElement) styleElement.remove();
                }
            }


            // 当前会话是否处于线下模式（群聊恒为 false）。
            // 给"+"面板等调用方做数据层判断，不依赖 DOM 上的置灰 class。
            function isOfflineModeActive(chatId = currentChatId, chatType = currentChatType) {
                if (chatType !== 'private' || !chatId) return false;
                const chat = Array.isArray(window.db?.characters)
                    ? db.characters.find(c => c.id === chatId)
                    : null;
                return !!(chat && chat.offlineModeEnabled);
            }

            // 统一控制线下模式的 UI 状态（按钮禁用 + 状态灯颜色）
            function updateOfflineModeUI(isOffline) {
                // 1. 处理顶部状态灯 (Requirement 4)
                const indicator = document.querySelector('.online-indicator');
                if (indicator) {
                    // 线下模式为粉色(#FF69B4)，线上模式恢复默认绿色(var(--online-status-color))
                    indicator.style.backgroundColor = isOffline ? 'var(--primary-color)' : 'var(--online-status-color)';

                }

                // 2. 处理 Sticker Bar 按钮 (Requirement 3)
                // 需要禁用的按钮 ID 列表
                // ⚠️ "+"面板里的线上功能（送礼物/发送位置）不是 <button>，disabled 无效，
                //    改由 chat_room.js 的 syncChatExpansionActiveState 置灰，别加到这个列表里。
                const buttonsToDisable = [
                    'voice-message-btn',       // 语音
                    'photo-video-btn',         // 照片/视频
                    'image-recognition-btn',   // 发送图片/识图
                    'sticker-toggle-btn',       // 表情包
                    'wallet-btn',              // 转账/钱包
                    'video-call-btn'           // 通话（线下模式无法通话）
                ];

                buttonsToDisable.forEach(btnId => {
                    const btn = document.getElementById(btnId);
                    if (btn) {
                        btn.disabled = isOffline; // true则禁用，false则启用
                        // 禁用时禁止点击事件，防止触发 ripple 动画或弹窗
                        btn.style.pointerEvents = isOffline ? 'none' : 'auto';
                    }
                });
            }