const createGroupBtn = document.getElementById('create-group-btn'),
    createGroupModal = document.getElementById('create-group-modal'),
    createGroupForm = document.getElementById('create-group-form'),
    memberSelectionList = document.getElementById('member-selection-list'),
    groupNameInput = document.getElementById('group-name-input'),
    groupSettingsSidebar = document.getElementById('group-settings-sidebar'),
    groupSettingsForm = document.getElementById('group-settings-form'),
    groupMembersListContainer = document.getElementById('group-members-list-container'),
    editGroupMemberModal = document.getElementById('edit-group-member-modal'),
    editGroupMemberForm = document.getElementById('edit-group-member-form');

const inviteMemberModal = document.getElementById('invite-member-modal'),
    inviteMemberSelectionList = document.getElementById('invite-member-selection-list'),
    confirmInviteBtn = document.getElementById('confirm-invite-btn'),
    removeMemberModal = document.getElementById('remove-member-modal'),
    removeMemberSelectionList = document.getElementById('remove-member-selection-list'),
    confirmRemoveMemberBtn = document.getElementById('confirm-remove-member-btn');

const groupRecipientSelectionModal = document.getElementById('group-recipient-selection-modal'),
    groupRecipientSelectionList = document.getElementById('group-recipient-selection-list'),
    confirmGroupRecipientBtn = document.getElementById('confirm-group-recipient-btn'),
    groupRecipientSelectionTitle = document.getElementById('group-recipient-selection-title');
const linkGroupWorldBookBtn = document.getElementById('link-group-world-book-btn');

// --- GROUP CHAT FUNCTIONS ---
function setupGroupChatSystem() {
    // 1. 打开创建群聊弹窗
    createGroupBtn.addEventListener('click', () => {
        renderMemberSelectionList();
        // 重置表单
        createGroupForm.reset();

        // 清空隐藏域
        if (document.getElementById('group-my-persona')) document.getElementById('group-my-persona').value = '';
        if (document.getElementById('group-selected-persona-id')) document.getElementById('group-selected-persona-id').value = '';
        if (document.getElementById('group-my-name')) document.getElementById('group-my-name').value = '';
        if (document.getElementById('group-my-nickname')) document.getElementById('group-my-nickname').value = '';

        // 重置绑定按钮状态
        const bindBtn = document.getElementById('create-group-select-persona-btn');
        if (bindBtn) {
            bindBtn.textContent = '选择群主';
            bindBtn.classList.remove('btn-secondary');
            bindBtn.classList.add('btn-primary');
        }

        createGroupModal.classList.add('visible');
    });

    // 2. 创建群聊弹窗中的"绑定人设"按钮逻辑
    const createGroupBindBtn = document.getElementById('create-group-select-persona-btn');
    if (createGroupBindBtn) {
        // 防止重复绑定，先克隆替换
        const newBtn = createGroupBindBtn.cloneNode(true);
        createGroupBindBtn.parentNode.replaceChild(newBtn, createGroupBindBtn);

        newBtn.addEventListener('click', () => {
            if (typeof window.openSelectPersonaModal === 'function') {
                window.openSelectPersonaModal((p) => {
                    if (p) {
                        // 填充数据
                        document.getElementById('group-selected-persona-id').value = p.id;
                        document.getElementById('group-my-name').value = p.realName;
                        document.getElementById('group-my-nickname').value = p.nickname;
                        document.getElementById('group-my-persona').value = p.persona;

                        // 改变按钮状态
                        newBtn.textContent = `✓ 群主: ${p.nickname}`;
                        newBtn.classList.remove('btn-primary');
                        newBtn.classList.add('btn-secondary');

                        showToast(`已选择群主：${p.nickname}`);
                    }
                });
            }
        });
    }

    // 3. 提交创建群聊
    createGroupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const selectedMemberIds = Array.from(memberSelectionList.querySelectorAll('input:checked')).map(input => input.value);
        const groupName = groupNameInput.value.trim();

        // 获取新的字段
        const myRealName = document.getElementById('group-my-name').value.trim();
        const myNickname = document.getElementById('group-my-nickname').value.trim();
        const myPersona = document.getElementById('group-my-persona').value.trim();
        const boundPersonaId = document.getElementById('group-selected-persona-id').value;

        if (selectedMemberIds.length < 1) return showToast('请至少选择一个群成员。');
        if (!groupName) return showToast('请输入群聊名称。');
        if (!myRealName) return showToast('请选择群主。');

        // 尝试获取绑定的头像，如果没有则用默认图
        let myAvatar = 'https://i.postimg.cc/GtbTnxhP/o-o-1.jpg';
        if (boundPersonaId) {
            const p = db.userPersonas.find(up => up.id === boundPersonaId);
            if (p) myAvatar = p.avatar;
        }

        const newGroup = {
            id: `group_${Date.now()}`,
            name: groupName,
            avatar: 'https://i.postimg.cc/fTLCngk1/image.jpg',
            me: {
                realName: myRealName,
                nickname: myNickname,
                persona: myPersona,
                avatar: myAvatar,
                boundPersonaId: boundPersonaId
            },
            members: selectedMemberIds.map(charId => {
                const char = db.characters.find(c => c.id === charId);
                return {
                    id: `member_${char.id}`,
                    originalCharId: char.id,
                    realName: char.realName,
                    groupNickname: char.remarkName,
                    persona: char.persona,
                    avatar: char.avatar
                };
            }),
            theme: 'white_blue',
            maxMemory: 10,
            chatBg: '',
            history: [],
            isPinned: false,
            unreadCount: 0,
            useCustomBubbleCss: (typeof _getBubblePresets === 'function' && _getBubblePresets().find(p => p.name === '默认')?.css) ? true : false,
            customBubbleCss: (typeof _getBubblePresets === 'function') ? (_getBubblePresets().find(p => p.name === '默认')?.css || '') : '',
            bubbleThemeName: 'default',
            worldBookIds: []
        };
        db.groups.push(newGroup);
        await saveSingleChat(newGroup.id, 'group');
        renderChatList();
        createGroupModal.classList.remove('visible');
        showToast(`群聊"${groupName}"创建成功！`);
    });

    // 4. 跳转到群聊信息页面（group_info）
    const sidebarGroupInfoBtn = document.getElementById('sidebar-group-info-btn');
    if (sidebarGroupInfoBtn) {
        sidebarGroupInfoBtn.addEventListener('click', () => {
            const group = db.groups.find(g => g.id === currentChatId);
            if (!group) return showToast('找不到群聊信息');

            // 关闭侧边栏
            const sidebar = document.getElementById('group-settings-sidebar');
            if (sidebar) sidebar.classList.remove('open');

            // 打开群聊信息页面
            if (typeof openGroupInfoScreen === 'function') {
                openGroupInfoScreen(group, 'chat-room');
            }
        });
    }

    // 6. 群头像上传
    document.getElementById('setting-group-avatar-upload').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            try {
                const compressedUrl = await compressImage(file, { quality: 0.8, maxWidth: 400, maxHeight: 400 });
                const group = db.groups.find(g => g.id === currentChatId);
                if (group) {
                    group.avatar = compressedUrl;
                    document.getElementById('setting-group-avatar-preview').src = compressedUrl;
                }
            } catch (error) {
                showToast('群头像压缩失败，请重试');
            }
        }
    });

    // 7. 群背景上传
    document.getElementById('setting-group-chat-bg-upload').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            try {
                const compressedUrl = await compressImage(file, {
                    quality: 0.85,
                    maxWidth: 1080,
                    maxHeight: 1920
                });
                const group = db.groups.find(g => g.id === currentChatId);
                if (group) {
                    group.chatBg = compressedUrl;
                    chatRoomScreen.style.backgroundImage = `url(${compressedUrl})`;
                    await saveSingleChat(currentChatId, 'group');
                    showToast('聊天背景已更换');
                }
            } catch (error) {
                showToast('群聊背景压缩失败，请重试');
            }
        }
    });

    // 清理图片：批量把本群聊的图片转成文字描述
    const cleanupGroupImagesBtn = document.getElementById('cleanup-group-images-btn');
    if (cleanupGroupImagesBtn) {
        cleanupGroupImagesBtn.addEventListener('click', () => {
            if (typeof cleanupChatImages === 'function') cleanupChatImages();
        });
    }

    // 8. 清空记录
    document.getElementById('clear-group-chat-history-btn').addEventListener('click', async () => {
        const group = db.groups.find(g => g.id === currentChatId);
        if (!group) return;
        if (await AppUI.confirm(`你确定要清空群聊"${group.name}"的所有聊天记录吗？这个操作是不可恢复的！`, "系统提示", "确认", "取消")) {
            group.history = [];
            await clearChatHistoryInDB(currentChatId);
            await saveSingleChat(currentChatId, 'group');
            renderMessages(false, true);
            renderChatList();
            groupSettingsSidebar.classList.remove('open');
            showToast('聊天记录已清空');
        }
    });

    // 9. 群成员点击事件
    // 注意：排除 .group-member-me（我自己的头像），那个由 renderGroupMembersInSettings 内单独绑定
    groupMembersListContainer.addEventListener('click', e => {
        const memberDiv = e.target.closest('.group-member:not(.group-member-me)');
        const addBtn = e.target.closest('.add-member-btn');
        const removeBtn = e.target.closest('.remove-member-btn');
        if (memberDiv) {
            openGroupMemberEditModal(memberDiv.dataset.id);
        } else if (addBtn) {
            // 只保留"邀请现有人设"这一条路径，直接弹出邀请框
            renderInviteSelectionList();
            inviteMemberModal.classList.add('visible');
        } else if (removeBtn) {
            renderRemoveSelectionList();
            removeMemberModal.classList.add('visible');
        }
    });

    // 10. 编辑成员头像上传
    document.getElementById('edit-member-avatar-preview').addEventListener('click', () => {
        document.getElementById('edit-member-avatar-upload').click();
    });
    document.getElementById('edit-member-avatar-upload').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            try {
                const compressedUrl = await compressImage(file, { quality: 0.8, maxWidth: 400, maxHeight: 400 });
                document.getElementById('edit-member-avatar-preview').src = compressedUrl;
            } catch (error) {
                showToast('成员头像压缩失败，请重试');
            }
        }
    });

    // 11. 提交成员编辑
    editGroupMemberForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const memberId = document.getElementById('editing-member-id').value;
        const group = db.groups.find(g => g.id === currentChatId);
        const member = group.members.find(m => m.id === memberId);
        if (member) {
            const oldNickname = member.groupNickname;
            const newNickname = document.getElementById('edit-member-group-nickname').value;
            member.avatar = document.getElementById('edit-member-avatar-preview').src;
            member.groupNickname = newNickname;
            member.realName = document.getElementById('edit-member-real-name').value;
            member.persona = document.getElementById('edit-member-persona').value;

            // 音色：关联了角色就写进角色库（播放时是按 originalCharId 回查角色的，
            // 写在成员副本上读不到）；没关联才退回写在成员身上
            const voiceSel = document.getElementById('edit-member-voice-preset');
            if (voiceSel && voiceSel.value) {
                const linkedChar = member.originalCharId
                    ? (db.characters || []).find(c => c.id === member.originalCharId)
                    : null;
                if (linkedChar) {
                    linkedChar.voicePresetId = voiceSel.value;
                    await saveSingleChat(linkedChar.id, 'private');
                } else {
                    member.voicePresetId = voiceSel.value;
                }
            }

            if (oldNickname !== newNickname) {
                // 只有真正改了昵称并发送通知时才触发时间跳过
                await processTimePerception(group, currentChatId, 'group');
                const myName = group.me.realName;
                const messageContent = `[${myName}修改${member.realName}的群昵称为：${newNickname}]`;
                const message = {
                    id: `msg_${Date.now()}`,
                    role: 'user',
                    content: messageContent,
                    parts: [{ type: 'text', text: messageContent }],
                    timestamp: Date.now()
                };
                group.history.push(message);
                addMessageBubble(message, group.id, 'group');
                await saveMessageToDB(message, currentChatId, 'group');
                showToast('成员昵称已变更');
            }

            await saveSingleChat(currentChatId, 'group');
            renderGroupMembersInSettings(group);
            document.querySelectorAll(`.message-wrapper[data-sender-id="${member.id}"] .group-nickname`).forEach(el => {
                el.textContent = member.groupNickname;
            });
        }
        editGroupMemberModal.classList.remove('visible');
    });

    // 12. 邀请成员逻辑（只支持邀请现有人设）
    confirmInviteBtn.addEventListener('click', async () => {
        const group = db.groups.find(g => g.id === currentChatId);
        if (!group) return;

        const selectedCharIds = Array.from(inviteMemberSelectionList.querySelectorAll('input:checked')).map(input => input.value);

        if (selectedCharIds.length > 0) {
            // 真正邀请了人才触发时间跳过
            await processTimePerception(group, currentChatId, 'group');
        }

        selectedCharIds.forEach(charId => {
            const char = db.characters.find(c => c.id === charId);
            if (char) {
                const newMember = {
                    id: `member_${char.id}`,
                    originalCharId: char.id,
                    realName: char.realName,
                    groupNickname: char.remarkName,
                    persona: char.persona,
                    avatar: char.avatar
                };
                group.members.push(newMember);
                // 之前被移出过的，重新入群后从归档里清掉
                if (group.removedMembers) {
                    group.removedMembers = group.removedMembers.filter(m => m.id !== newMember.id);
                }
                sendInviteNotification(group, newMember.realName);
            }
        });
        if (selectedCharIds.length > 0) {
            await saveSingleChat(currentChatId, 'group');
            renderGroupMembersInSettings(group);
            renderMessages(false, true);
            showToast('已邀请新成员');
        }
        inviteMemberModal.classList.remove('visible');
    });
    // 12b. 移除成员逻辑
    confirmRemoveMemberBtn.addEventListener('click', async () => {
        const group = db.groups.find(g => g.id === currentChatId);
        if (!group) return;

        const selectedMemberIds = Array.from(removeMemberSelectionList.querySelectorAll('input:checked')).map(input => input.value);
        if (selectedMemberIds.length === 0) {
            return showToast('请至少选择一个要移除的成员。');
        }

        const targets = group.members.filter(m => selectedMemberIds.includes(m.id));
        const names = targets.map(m => m.groupNickname || m.realName).join('、');
        const ok = await AppUI.confirm(
            `确定把 ${names} 移出群聊"${group.name}"吗？\n聊天记录会保留，但他们不会再参与后续对话。`,
            '移除群成员', '确认移除', '取消'
        );
        if (!ok) return;

        // 真正移除了人才触发时间跳过
        await processTimePerception(group, currentChatId, 'group');

        // 归档到 removedMembers：历史气泡还要靠它取头像和群昵称
        if (!group.removedMembers) group.removedMembers = [];
        for (const member of targets) {
            if (!group.removedMembers.some(m => m.id === member.id)) {
                group.removedMembers.push({ ...member });
            }
            group.members = group.members.filter(m => m.id !== member.id);
            await sendRemoveNotification(group, member.realName);
        }

        await saveSingleChat(currentChatId, 'group');
        renderGroupMembersInSettings(group);
        renderMessages(false, true);
        renderChatList();
        showToast(`已将 ${names} 移出群聊`);
        removeMemberModal.classList.remove('visible');
    });

    // 13. 设置：我的头像上传（隐藏 input，供保存逻辑读取）
    document.getElementById('setting-group-my-avatar-upload').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            try {
                const compressedUrl = await compressImage(file, { quality: 0.8, maxWidth: 400, maxHeight: 400 });
                document.getElementById('setting-group-my-avatar-preview').src = compressedUrl;
            } catch (error) {
                showToast('头像压缩失败');
            }
        }
    });

    // 14. 互动功能：选择接收人
    confirmGroupRecipientBtn.addEventListener('click', () => {
        const selectedRecipientIds = Array.from(groupRecipientSelectionList.querySelectorAll('input:checked')).map(input => input.value);
        if (selectedRecipientIds.length === 0) {
            return showToast('请至少选择一个收件人。');
        }
        currentGroupAction.recipients = selectedRecipientIds;
        groupRecipientSelectionModal.classList.remove('visible');

        if (currentGroupAction.type === 'transfer') {
            const form = document.getElementById('send-transfer-form');
            if (form) form.reset();
            const modal = document.getElementById('send-transfer-modal');
            if (modal) modal.classList.add('visible');
        } else if (currentGroupAction.type === 'gift') {
            const form = document.getElementById('send-gift-form');
            if (form) form.reset();
            const modal = document.getElementById('send-gift-modal');
            if (modal) modal.classList.add('visible');
        }
    });

    // 15. 关联世界书
    linkGroupWorldBookBtn.addEventListener('click', () => {
        const group = db.groups.find(g => g.id === currentChatId);
        if (!group) return;
        renderCategorizedWorldBookList(document.getElementById('world-book-selection-list'), db.worldBooks, group.worldBookIds || [], 'wb-select-group');
        document.getElementById('world-book-selection-modal').classList.add('visible');
    });

    // 16. 最大记忆轮数：点击菜单唤起输入弹窗（与私聊一致）
    const groupMaxMemoryItem = document.getElementById('setting-group-max-memory-item');
    if (groupMaxMemoryItem) {
        groupMaxMemoryItem.addEventListener('click', async () => {
            const currentVal = document.getElementById('setting-group-max-memory').value || 10;
            const result = await AppUI.prompt('请输入最大记忆轮数', currentVal, '最大记忆轮数', '确定', '取消');
            if (result !== null) {
                const num = parseInt(result, 10);
                if (!isNaN(num) && num > 0) {
                    // ★ maxMemory 上限 1000（必须 < 懒加载内存窗口 1500）
                    const capped = Math.min(num, 1000);
                    document.getElementById('setting-group-max-memory').value = capped;
                    document.getElementById('setting-group-max-memory-display').textContent = capped;
                    if (capped < num) showToast('最大记忆轮数已限制为 1000');
                } else {
                    showToast('请输入有效的正整数');
                }
            }
        });
    }

    // 回复条数：格式“最低数-最高数”，留空为默认（按群成员数计算）
    const groupReplyRangeItem = document.getElementById('setting-group-reply-range-item');
    if (groupReplyRangeItem) {
        groupReplyRangeItem.addEventListener('click', async () => {
            const currentVal = document.getElementById('setting-group-reply-range').value || '';
            const result = await AppUI.prompt('请输入回复条数范围，格式“最低数-最高数”（如 6-15）；留空按群成员数自动计算', currentVal, '回复条数', '确定', '取消');
            if (result === null) return; // 取消
            const trimmed = result.trim();
            if (trimmed === '') {
                document.getElementById('setting-group-reply-range').value = '';
                document.getElementById('setting-group-reply-range-display').textContent = '默认';
                return;
            }
            const m = trimmed.match(/^(\d+)\s*-\s*(\d+)$/);
            if (!m) { showToast('格式不正确，请输入如 6-15'); return; }
            const lo = parseInt(m[1], 10), hi = parseInt(m[2], 10);
            if (lo <= 0 || hi < lo) { showToast('请确保最低数≥1且不大于最高数'); return; }
            const normalized = `${lo}-${hi}`;
            document.getElementById('setting-group-reply-range').value = normalized;
            document.getElementById('setting-group-reply-range-display').textContent = normalized;
        });
    }

    // 天气：点整行唤起弹窗（选地点 + 是否含预报），取消不写入
    const groupWeatherItem = document.getElementById('setting-group-weather-item');
    if (groupWeatherItem) {
        groupWeatherItem.addEventListener('click', async () => {
            if (typeof openWeatherSettingDialog !== 'function') return;
            const result = await openWeatherSettingDialog({
                weatherMode: document.getElementById('setting-group-weather-mode').value || 'off',
                weatherLocationPresetId: document.getElementById('setting-group-weather-preset').value || '',
                weatherForecastEnabled: document.getElementById('setting-group-weather-forecast').value === '1'
            });
            if (!result) return;
            document.getElementById('setting-group-weather-mode').value = result.weatherMode;
            document.getElementById('setting-group-weather-preset').value = result.weatherLocationPresetId;
            document.getElementById('setting-group-weather-forecast').value = result.weatherForecastEnabled ? '1' : '0';
            _refreshGroupWeatherDisplay();
        });
    }

    // 图像生成：只写群对象，不把预设复制到任何群成员。
    const groupImageGenerationItem = document.getElementById('setting-group-image-item');
    if (groupImageGenerationItem) {
        groupImageGenerationItem.addEventListener('click', async () => {
            if (typeof openImageGenerationSettingDialog !== 'function') return;
            const result = await openImageGenerationSettingDialog({
                imageApiPresetId: document.getElementById('setting-group-image-preset').value || '',
                imageAutoGenerate: document.getElementById('setting-group-image-auto').value === '1',
                imageContentRule: document.getElementById('setting-group-image-rule').value || '',
                imageStylePrompt: document.getElementById('setting-group-image-style').value || '',
                imageReference: document.getElementById('setting-group-image-reference').value || ''
            });
            if (!result) return;
            document.getElementById('setting-group-image-preset').value = result.imageApiPresetId;
            document.getElementById('setting-group-image-auto').value = result.imageAutoGenerate ? '1' : '0';
            document.getElementById('setting-group-image-rule').value = result.imageContentRule;
            document.getElementById('setting-group-image-style').value = result.imageStylePrompt;
            document.getElementById('setting-group-image-reference').value = result.imageReference;
            _refreshGroupImageGenerationDisplay();
        });
    }
}

/** 按隐藏 input 的当前值刷新群聊侧栏天气行文案 */
function _refreshGroupWeatherDisplay() {
    const display = document.getElementById('setting-group-weather-display');
    if (!display || typeof formatWeatherSettingLabel !== 'function') return;
    display.textContent = formatWeatherSettingLabel(
        document.getElementById('setting-group-weather-mode').value || 'off',
        document.getElementById('setting-group-weather-preset').value || '',
        document.getElementById('setting-group-weather-forecast').value === '1'
    );
}

/** 按隐藏 input 的当前值刷新群聊侧栏图像生成文案。 */
function _refreshGroupImageGenerationDisplay() {
    const display = document.getElementById('setting-group-image-display');
    if (!display || typeof formatImageGenerationSettingLabel !== 'function') return;
    display.textContent = formatImageGenerationSettingLabel(
        document.getElementById('setting-group-image-preset').value || '',
        document.getElementById('setting-group-image-auto').value === '1'
    );
}

// --- 辅助函数 ---

function renderMemberSelectionList() {
    memberSelectionList.innerHTML = '';
    if (db.characters.length === 0) {
        memberSelectionList.innerHTML = '<li style="color:#aaa; text-align:center; padding: 10px 0;">没有可选择的人设。</li>';
        return;
    }
    db.characters.forEach(char => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `<input type="checkbox" id="select-${char.id}" value="${char.id}"><img src="${char.avatar}" alt="${char.remarkName}"><label for="select-${char.id}">${char.remarkName}（${char.realName}）</label>`;
        memberSelectionList.appendChild(li);
    });
}

function loadGroupSettingsToSidebar() {
    const group = db.groups.find(g => g.id === currentChatId);
    if (!group) return;

    // ── 顶部：群头像 + 群名称显示（只读）────────────────
    document.getElementById('setting-group-avatar-preview').src = group.avatar;
    const nameDisplay = document.getElementById('setting-group-name-display');
    if (nameDisplay) nameDisplay.textContent = group.name;
    // 隐藏 input 保留群名，供保存逻辑读取
    document.getElementById('setting-group-name').value = group.name;

    // ── 我的信息（填充隐藏字段，供保存逻辑使用）─────────
    let myAvatar   = group.me.avatar;
    let myRealName = group.me.realName || group.me.nickname; // 兼容旧数据
    let myNickname = group.me.nickname;
    let myPersona  = group.me.persona;

    if (group.me.boundPersonaId) {
        const p = db.userPersonas.find(up => up.id === group.me.boundPersonaId);
        if (p) {
            myAvatar   = p.avatar;
            myRealName = p.realName;
            myPersona  = p.persona;
        }
    }

    // 隐藏字段（saveGroupSettingsFromSidebar 读取）
    document.getElementById('setting-group-my-avatar-preview').src = myAvatar;
    document.getElementById('setting-group-my-realname').value     = myRealName;
    document.getElementById('setting-group-my-nickname').value     = myNickname;
    document.getElementById('setting-group-my-persona').value      = myPersona;
    document.getElementById('group-settings-form').dataset.pendingBindId = group.me.boundPersonaId || '';

    // ── 记忆轮数 ─────────────────────────────────────────
    document.getElementById('setting-group-max-memory').value = group.maxMemory || 10;
    const maxMemDisplay = document.getElementById('setting-group-max-memory-display');
    if (maxMemDisplay) maxMemDisplay.textContent = group.maxMemory || 10;

    document.getElementById('setting-group-reply-range').value = group.replyRange || '';
    const groupReplyRangeDisplay = document.getElementById('setting-group-reply-range-display');
    if (groupReplyRangeDisplay) groupReplyRangeDisplay.textContent = group.replyRange || '默认';
    const groupTimePEl = document.getElementById('setting-group-time-perception');
if (groupTimePEl) groupTimePEl.checked = group.timePerceptionEnabled || false;

    // ── 渲染成员列表（含我的头像排第一）─────────────────
    renderGroupMembersInSettings(group);

const groupApiPresetSel = document.getElementById('setting-group-api-preset');
if (groupApiPresetSel) {
    if (typeof window.populateChatApiPresetSelect === 'function') {
        window.populateChatApiPresetSelect(groupApiPresetSel);
    } else {
        const presets = (db.apiPresets || []).filter(p => !p.type || p.type === 'chat');
        groupApiPresetSel.innerHTML = '<option value="">全局默认</option>';
        presets.forEach(p => {
            const opt = document.createElement('option');
            opt.value = p.name; opt.textContent = p.name;
            groupApiPresetSel.appendChild(opt);
        });
    }
    groupApiPresetSel.value = group.chatApiPreset || '';
}

// 天气：隐藏 input 暂存，侧栏只显示文案，具体设置走弹窗
const groupWeatherModeInput = document.getElementById('setting-group-weather-mode');
if (groupWeatherModeInput) {
    groupWeatherModeInput.value = group.weatherMode || 'off';
    document.getElementById('setting-group-weather-preset').value = group.weatherLocationPresetId || '';
    document.getElementById('setting-group-weather-forecast').value = group.weatherForecastEnabled ? '1' : '0';
    _refreshGroupWeatherDisplay();
}
const groupImagePresetInput = document.getElementById('setting-group-image-preset');
const groupImageAutoInput = document.getElementById('setting-group-image-auto');
if (groupImagePresetInput && groupImageAutoInput) {
    const binding = typeof normalizeChatImageBinding === 'function'
        ? normalizeChatImageBinding(group)
        : {
            imageApiPresetId: group.imageApiPresetId || 'off',
            imageAutoGenerate: !!group.imageAutoGenerate,
            imageContentRule: group.imageContentRule || '',
            imageStylePrompt: group.imageStylePrompt || '',
            imageReference: group.imageReference || ''
        };
    groupImagePresetInput.value = binding.imageApiPresetId;
    groupImageAutoInput.value = binding.imageAutoGenerate ? '1' : '0';
    const groupImageRuleInput = document.getElementById('setting-group-image-rule');
    const groupImageStyleInput = document.getElementById('setting-group-image-style');
    const groupImageRefInput = document.getElementById('setting-group-image-reference');
    if (groupImageRuleInput) groupImageRuleInput.value = binding.imageContentRule;
    if (groupImageStyleInput) groupImageStyleInput.value = binding.imageStylePrompt;
    if (groupImageRefInput) groupImageRefInput.value = binding.imageReference;
    _refreshGroupImageGenerationDisplay();
}
    // ── 气泡外观 ─────────────────────────────────────────
    if (typeof window.populateChatThemeSelects === 'function') {
        window.populateChatThemeSelects();
    }
    const themeSelect = document.getElementById('setting-group-theme-color');
    if (themeSelect) {
        if (group.useCustomBubbleCss && group.bubbleThemeName && group.bubbleThemeName !== 'default' && group.bubbleThemeName !== '默认') {
            const optExists = Array.from(themeSelect.options).some(o => o.value === `preset:${group.bubbleThemeName}`);
            themeSelect.value = optExists ? `preset:${group.bubbleThemeName}` : 'default';
        } else {
            themeSelect.value = 'default';
        }
    }
}

function renderGroupMembersInSettings(group) {
    groupMembersListContainer.innerHTML = '';

    // ── 我自己（第一个，金色描边）────────────────────────
    const meDiv = document.createElement('div');
    meDiv.className = 'group-member group-member-me';
    meDiv.innerHTML = `
        <img src="${group.me.avatar}" alt="${group.me.nickname}">
        <span>${group.me.nickname}</span>
    `;
    // 点击弹窗修改群昵称
    meDiv.addEventListener('click', async () => {
        const currentNickname = document.getElementById('setting-group-my-nickname').value || group.me.nickname;
        const result = await AppUI.prompt('修改我的群昵称', currentNickname, '群昵称', '确定', '取消');
        if (result !== null && result.trim()) {
            const trimmed = result.trim();
            document.getElementById('setting-group-my-nickname').value = trimmed;
            meDiv.querySelector('span').textContent = trimmed;
        }
    });
    groupMembersListContainer.appendChild(meDiv);

    // ── 我与其他成员之间的竖线分隔 ───────────────────────
    const separator = document.createElement('div');
    separator.className = 'group-member-me-separator';
    groupMembersListContainer.appendChild(separator);

    // ── 其他成员 ─────────────────────────────────────────
    group.members.forEach(member => {
        const memberDiv = document.createElement('div');
        memberDiv.className = 'group-member';
        memberDiv.dataset.id = member.id;
        memberDiv.innerHTML = `<img src="${member.avatar}" alt="${member.groupNickname}"><span>${member.groupNickname}</span>`;
        groupMembersListContainer.appendChild(memberDiv);
    });

    // ── 添加按钮 ──────────────────────────────────────────
    const addBtn = document.createElement('div');
    addBtn.className = 'add-member-btn';
    addBtn.innerHTML = `<div class="add-icon">+</div><span>添加</span>`;
    groupMembersListContainer.appendChild(addBtn);

    // ── 移除按钮（紧跟添加按钮）───────────────────────────
    if (group.members.length > 0) {
        const removeBtn = document.createElement('div');
        removeBtn.className = 'remove-member-btn';
        removeBtn.innerHTML = `<div class="remove-icon">−</div><span>移除</span>`;
        groupMembersListContainer.appendChild(removeBtn);
    }
}

function renderGroupRecipientSelectionList(actionText) {
    const group = db.groups.find(g => g.id === currentChatId);
    if (!group) return;
    groupRecipientSelectionTitle.textContent = actionText;
    groupRecipientSelectionList.innerHTML = '';
    group.members.forEach(member => {
        const li = document.createElement('li');
        li.className = 'group-recipient-select-item';
        li.innerHTML = `
            <input type="checkbox" id="recipient-select-${member.id}" value="${member.id}">
            <label for="recipient-select-${member.id}">
                <img src="${member.avatar}" alt="${member.groupNickname}">
                <span>${member.groupNickname}</span>
            </label>`;
        groupRecipientSelectionList.appendChild(li);
    });
}

async function saveGroupSettingsFromSidebar() {
    const group = db.groups.find(g => g.id === currentChatId);
    if (!group) return;

    const oldName = group.name;
    const newName = document.getElementById('setting-group-name').value;
    const oldMeNickname = group.me.nickname;
    const newMeNickname = document.getElementById('setting-group-my-nickname').value;

    // 如果群名或我的昵称发生了实质性改变，才触发时间跳过
    if (oldName !== newName || oldMeNickname !== newMeNickname) {
        await processTimePerception(group, currentChatId, 'group');
    }

    if (oldName !== newName) {
        group.name = newName;
        sendRenameNotification(group, newName);
    }
    group.avatar = document.getElementById('setting-group-avatar-preview').src;

    // --- 保存我的信息 ---
    const pendingBindId = document.getElementById('group-settings-form').dataset.pendingBindId;
    if (oldMeNickname !== newMeNickname) {
        const messageContent = `[${group.me.realName}将自己的群昵称修改为：${newMeNickname}]`;
        const message = {
            id: `msg_${Date.now()}_self_rename`,
            role: 'user',
            content: messageContent,
            parts: [{ type: 'text', text: messageContent }],
            timestamp: Date.now()
        };
        group.history.push(message);
        await saveMessageToDB(message, currentChatId, 'group');
    }

    group.me.avatar    = document.getElementById('setting-group-my-avatar-preview').src;
    group.me.realName  = document.getElementById('setting-group-my-realname').value;
    group.me.nickname  = document.getElementById('setting-group-my-nickname').value;
    group.me.persona   = document.getElementById('setting-group-my-persona').value;

    if (pendingBindId) {
        group.me.boundPersonaId = pendingBindId;
    }

    group.maxMemory = document.getElementById('setting-group-max-memory').value;
    group.replyRange = document.getElementById('setting-group-reply-range').value || '';
    const groupTimePEl = document.getElementById('setting-group-time-perception');
if (groupTimePEl) group.timePerceptionEnabled = groupTimePEl.checked;


    // 【核心变更】保存群聊气泡预设
    const themeSelect = document.getElementById('setting-group-theme-color');
    if (themeSelect) {
        const themeVal = themeSelect.value;
        if (themeVal === 'default') {
            const presets = (typeof _getBubblePresets === 'function') ? _getBubblePresets() : [];
            const defaultPreset = presets.find(p => p.name === '默认');

            group.theme = 'white_blue';
            if (defaultPreset && defaultPreset.css) {
                group.useCustomBubbleCss = true;
                group.customBubbleCss = defaultPreset.css;
            } else {
                group.useCustomBubbleCss = false;
                group.customBubbleCss = '';
            }
            group.bubbleThemeName = 'default';

        } else if (themeVal && themeVal.startsWith('preset:')) {
            const presetName = themeVal.replace('preset:', '');
            const presets = (typeof _getBubblePresets === 'function') ? _getBubblePresets() : [];
            const preset = presets.find(p => p.name === presetName);
            if (preset) {
                group.theme = 'white_blue';
                group.useCustomBubbleCss = true;
                group.customBubbleCss = preset.css;
                group.bubbleThemeName = presetName;
            }
        }
    }

    if (typeof updateCustomBubbleStyle === 'function') {
        updateCustomBubbleStyle(currentChatId, group.customBubbleCss, group.useCustomBubbleCss);
    }
const groupApiPresetSel = document.getElementById('setting-group-api-preset');
if (groupApiPresetSel) {
    group.chatApiPreset = groupApiPresetSel.value;
}
const groupWeatherModeInputSave = document.getElementById('setting-group-weather-mode');
if (groupWeatherModeInputSave) {
    group.weatherMode = groupWeatherModeInputSave.value || 'off';
    group.weatherLocationPresetId = document.getElementById('setting-group-weather-preset').value || '';
    group.weatherForecastEnabled = document.getElementById('setting-group-weather-forecast').value === '1';
}
const groupImagePresetInputSave = document.getElementById('setting-group-image-preset');
const groupImageAutoInputSave = document.getElementById('setting-group-image-auto');
if (groupImagePresetInputSave && groupImageAutoInputSave) {
    group.imageApiPresetId = groupImagePresetInputSave.value || 'off';
    group.imageAutoGenerate = groupImageAutoInputSave.value === '1';
    const groupImageRuleSave = document.getElementById('setting-group-image-rule');
    const groupImageStyleSave = document.getElementById('setting-group-image-style');
    const groupImageRefSave = document.getElementById('setting-group-image-reference');
    if (groupImageRuleSave) group.imageContentRule = groupImageRuleSave.value || '';
    if (groupImageStyleSave) group.imageStylePrompt = groupImageStyleSave.value || '';
    if (groupImageRefSave) group.imageReference = groupImageRefSave.value || '';
}
    await saveSingleChat(currentChatId, 'group');
    showToast('群聊设置已保存！');
    chatRoomTitle.textContent = group.name;
    renderChatList();
    renderMessages(false, true);
}

function openGroupMemberEditModal(memberId) {
    const group = db.groups.find(g => g.id === currentChatId);
    const member = group.members.find(m => m.id === memberId);
    if (!member) return;

    document.getElementById('edit-group-member-title').textContent = `修改群昵称`;
    document.getElementById('editing-member-id').value = member.id;

    // 核心逻辑：检查是否关联了原始角色
    let isLinkedCharacter = false;
    let originalChar = null;

    if (member.originalCharId) {
        originalChar = db.characters.find(c => c.id === member.originalCharId);
        if (originalChar) {
            isLinkedCharacter = true;
            // 强制同步：使用原始角色的最新数据
            member.avatar = originalChar.avatar;
            member.realName = originalChar.realName;
            member.persona = originalChar.persona;
        }
    }

    // 填充数据
    document.getElementById('edit-member-avatar-preview').src = member.avatar;
    document.getElementById('edit-member-group-nickname').value = member.groupNickname;
    document.getElementById('edit-member-real-name').value = member.realName;
    document.getElementById('edit-member-persona').value = member.persona;

    // --- 如果是关联角色，禁用关键字段 ---
    const realNameInput = document.getElementById('edit-member-real-name');
    const personaInput = document.getElementById('edit-member-persona');
    const avatarPreview = document.getElementById('edit-member-avatar-preview');

    if (isLinkedCharacter) {
        realNameInput.disabled = true;
        personaInput.disabled = true;
        personaInput.placeholder = "该内容已与角色库同步，无法在群聊中修改。";
        if (avatarPreview) avatarPreview.style.pointerEvents = 'none';
    } else {
        realNameInput.disabled = false;
        personaInput.disabled = false;
        personaInput.placeholder = "详细描述角色的性格、背景等。";
        if (avatarPreview) avatarPreview.style.pointerEvents = 'auto';
    }

    // 音色下拉。★ 关联角色时读写的是**角色库**那份 voicePresetId，不是成员副本 ——
    //   群聊播放时按 senderId → originalCharId → 角色 解析，存到成员上根本读不到。
    //   没关联角色的成员（角色被删了，或直接在群里建的）才退回存在成员自己身上。
    const voiceSel = document.getElementById('edit-member-voice-preset');
    const voiceHint = document.getElementById('edit-member-voice-hint');
    if (voiceSel && typeof getVoicePresetOptions === 'function') {
        voiceSel.innerHTML = '';
        getVoicePresetOptions().forEach(o => {
            const opt = document.createElement('option');
            opt.value = o.value;
            opt.textContent = o.label;
            voiceSel.appendChild(opt);
        });
        const source = isLinkedCharacter ? originalChar : member;
        const want = (source && source.voicePresetId) || VOICE_PRESET_OFF;
        voiceSel.value = [...voiceSel.options].some(o => o.value === want)
            ? want : VOICE_PRESET_OFF;
        if (voiceHint) {
            voiceHint.textContent = isLinkedCharacter
                ? '与角色库同步，改这里也会影响该角色的私聊'
                : '该成员没有关联角色，音色只在这个群里生效';
        }
    }

    editGroupMemberModal.classList.add('visible');
}

function renderInviteSelectionList() {
    inviteMemberSelectionList.innerHTML = '';
    const group = db.groups.find(g => g.id === currentChatId);
    if (!group) return;
    const currentMemberCharIds = new Set(group.members.map(m => m.originalCharId));
    const availableChars = db.characters.filter(c => !currentMemberCharIds.has(c.id));
    if (availableChars.length === 0) {
        inviteMemberSelectionList.innerHTML = '<li style="color:#aaa; text-align:center; padding: 10px 0;">没有可邀请的新成员了。</li>';
        confirmInviteBtn.disabled = true;
        return;
    }
    confirmInviteBtn.disabled = false;
    availableChars.forEach(char => {
        const li = document.createElement('li');
        li.className = 'invite-member-select-item';
        li.innerHTML = `<input type="checkbox" id="invite-select-${char.id}" value="${char.id}"><label for="invite-select-${char.id}"><img src="${char.avatar}" alt="${char.remarkName}"><span>${char.remarkName}</span></label>`;
        inviteMemberSelectionList.appendChild(li);
    });
}

function renderRemoveSelectionList() {
    removeMemberSelectionList.innerHTML = '';
    const group = db.groups.find(g => g.id === currentChatId);
    if (!group) return;
    const members = group.members || [];
    if (members.length === 0) {
        removeMemberSelectionList.innerHTML = '<li style="color:#aaa; text-align:center; padding: 10px 0;">群里没有可移除的成员了。</li>';
        confirmRemoveMemberBtn.disabled = true;
        return;
    }
    confirmRemoveMemberBtn.disabled = false;
    members.forEach(member => {
        const li = document.createElement('li');
        li.className = 'invite-member-select-item';
        const label = member.groupNickname || member.realName;
        li.innerHTML = `<input type="checkbox" id="remove-select-${member.id}" value="${member.id}"><label for="remove-select-${member.id}"><img src="${member.avatar}" alt="${label}"><span>${label}</span></label>`;
        removeMemberSelectionList.appendChild(li);
    });
}

async function sendInviteNotification(group, newMemberRealName) {
    const messageContent = `[${group.me.realName}邀请${newMemberRealName}加入了群聊]`;
    const message = {
        id: `msg_${Date.now()}`,
        role: 'user',
        content: messageContent,
        parts: [{ type: 'text', text: messageContent }],
        timestamp: Date.now(),
        senderId: 'user_me'
    };
    group.history.push(message);
    await saveMessageToDB(message, group.id, 'group');
}

async function sendRemoveNotification(group, removedMemberRealName) {
    const messageContent = `[${group.me.realName}将${removedMemberRealName}移出了群聊]`;
    const message = {
        id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        role: 'user',
        content: messageContent,
        parts: [{ type: 'text', text: messageContent }],
        timestamp: Date.now(),
        senderId: 'user_me'
    };
    group.history.push(message);
    await saveMessageToDB(message, group.id, 'group');
}

async function sendRenameNotification(group, newName) {
    const myName = group.me.realName;
    const messageContent = `[${myName}修改群名为：${newName}]`;
    const message = {
        id: `msg_${Date.now()}`,
        role: 'user',
        content: messageContent,
        parts: [{ type: 'text', text: messageContent }],
        timestamp: Date.now()
    };
    group.history.push(message);
    await saveMessageToDB(message, group.id, 'group');
}
